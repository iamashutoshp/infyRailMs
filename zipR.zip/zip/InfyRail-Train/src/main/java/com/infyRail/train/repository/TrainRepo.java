package com.infyRail.train.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infyRail.train.dto.TrainDTO;
import com.infyRail.train.entity.TrainEntity;

public interface TrainRepo extends JpaRepository<TrainEntity,Integer>{
	
	public List<TrainEntity> findByRouteId(Integer id);
	Optional<TrainEntity> findByIdAndRouteId(int id,int routeId);
	
}
