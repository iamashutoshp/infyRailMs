package com.infyRail.train.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infyRail.train.dto.RouteDTO;
import com.infyRail.train.dto.TrainDTO;
import com.infyRail.train.service.TrainService;

@RestController
@RequestMapping("/trains")
@Validated
public class TrainController {

	@Autowired
	TrainService trainService;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	@PostMapping(consumes = "application/json")
	public ResponseEntity<String> createTrain(@RequestBody TrainDTO trainDTO) {
		Integer routId = trainDTO.getRouteId();
		System.out.println(routId);
		return ResponseEntity.ok(trainService.createTrain(trainDTO));
	}

	@PutMapping(value = "/{trainid}")
	public ResponseEntity<String> updateTrain(@PathVariable("trainid") String id, @RequestParam String fare) {

		System.out.println("fare " + fare);
		return ResponseEntity.ok(trainService.updateTrain(id, fare));
	}

	@GetMapping
	public List<TrainDTO> getTrainsForRoutes(@RequestParam("routeId") Integer id) {
		System.out.println("Inside TrainController.getRoutes()");
		System.out.println("--------Fetching List of Trains for a give route for routeId : " + id + "-------");
		return trainService.getRoutes(id);
	}

	@DeleteMapping("/{routeId}/{trainId}")
	public Map<String, Boolean> deleteTrainForRoute(@PathVariable("routeId") String route,
			@PathVariable("trainId") String train) {
		log.info("deleteTrainForRoute.........................");
		System.out.println(route + "  " + train);
		int trainId = Integer.parseInt(train);
		int routeId = Integer.parseInt(route);
		TrainDTO deleteTrainDTO = trainService.deleteTrainforRoute(routeId, trainId);
		System.out.println(deleteTrainDTO);
		Map<String, Boolean> response = new HashMap<>();
	     response.put("deleted", deleteTrainDTO != null);
//		return deleteTrainDTO == null
//				? new ResponseEntity<>("Provided train does not exist on this route", HttpStatus.BAD_REQUEST)
//				: new ResponseEntity<>("train No." + deleteTrainDTO.getId() + " deleted", HttpStatus.OK);
	     
	     return response;
	}
	
	@PutMapping(value="/{routeid}/json")
	public ResponseEntity<String> updateTrain(@PathVariable("routeid") String id,
			@Valid @RequestBody TrainDTO trainDTO) {
		log.info("updatingTrain............ with routeId : "+id+" train : "+trainDTO);
		boolean result=trainService.updateGivenTrainforRoute(id,trainDTO);
		return result? ResponseEntity.ok("Successfully update Train : "+trainDTO +" for routeId : "+id):ResponseEntity.badRequest().body("Error in updating Train : "+trainDTO +" for routeId : "+id);
	}
}
