package com.infyRail.train.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.infyRail.train.dto.RouteDTO;
import com.infyRail.train.dto.TrainDTO;
import com.infyRail.train.entity.TrainEntity;
import com.infyRail.train.repository.TrainRepo;

@Service
public class TrainService {

	@Autowired
	TrainRepo trainRepo;
	@Autowired
	private Environment environment;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	public String createTrain(TrainDTO trainDTO) {
//		TrainEntity en=TrainDTO.changesTo(trainDTO);
//		trainRepo.saveAndFlush(en);
//		System.out.println("id "+en.getId());
//		return Integer.toString(en.getId());

		TrainEntity trainEntity = TrainDTO.prepareTrainEntity(trainDTO);
		trainRepo.saveAndFlush(trainEntity);

		System.out.println("created train in TrainService.createTrain() for trainObj : " + trainDTO);
		return Integer.toString(trainEntity.getId());
	}

	public String updateTrain(String id, String fare) {

//		Optional<TrainEntity> en=trainRepo.findById(Integer.parseInt(id));
//		try {
//			TrainEntity tent=en.get();
//			tent.setFare(Double.parseDouble(fare));
//			trainRepo.saveAndFlush(tent);
//			return "Success: Fare gets Updated";
//		} catch (Exception e) {
//			return "Failed: Could not update the fare";
//			// TODO: handle exception
//		}
		Optional<TrainEntity> trainOptional = trainRepo.findById(Integer.parseInt(id));
		TrainEntity trainEntity = null;
		try {
			trainEntity = trainOptional.get();
			trainEntity.setFare(Double.parseDouble(fare));
			trainRepo.saveAndFlush(trainEntity);
		} catch (Exception e) {
			return environment.getProperty("train.fare.NotUpdated") + " : " + fare;
		}
		return environment.getProperty("train.fare.updated") + " : " + fare;
	}

	public List<TrainDTO> getRoutes(Integer id) {
		List<TrainEntity> getRoutes = trainRepo.findByRouteId(id);
		List<TrainDTO> getRoutesRes = new ArrayList<>();
		for (TrainEntity trainEntity : getRoutes)
			getRoutesRes.add(TrainDTO.prepareTrainDTO(trainEntity));
		return getRoutesRes;
	}

	public List<TrainDTO> fetchTrainsBySourceDestination(Integer id) {
		List<TrainEntity> trains = trainRepo.findByRouteId(id);
		List<TrainDTO> trainDTOs = new ArrayList<>();

		for (TrainEntity trainEntity : trains)
			trainDTOs.add(TrainDTO.prepareTrainDTO(trainEntity));

		return trainDTOs;
	}

	@Transactional
	public TrainDTO deleteTrainforRoute(int routeId, int trainId) {
		TrainDTO deletedTrain = null;
		Optional<TrainEntity> optional = trainRepo.findByIdAndRouteId(trainId, routeId);

		if (optional.isPresent()) {
			deletedTrain = TrainDTO.prepareTrainDTO(optional.get());
			if (deletedTrain.getRouteId() != routeId)
				return new TrainDTO();
			trainRepo.delete(TrainDTO.prepareTrainEntity(deletedTrain));
		}
		return deletedTrain;
	}

	@Transactional
	public boolean updateGivenTrainforRoute(String id, @Valid TrainDTO trainDTO) {
		log.info("inside updateGivenTrainforRoute.............................");
		boolean res = false;
		try {
			int routeId = Integer.parseInt(id);
			Optional<TrainEntity> optional = trainRepo.findByIdAndRouteId(trainDTO.getId(),routeId);
			if (optional.isPresent()) {
				log.info("updatingGivenTrainforRoute............................."+optional.get());
				trainDTO.setRouteId(routeId);
				trainRepo.saveAndFlush(TrainDTO.prepareTrainEntity(trainDTO));
				res=true;
			}
		} catch (Exception e) {
			log.error("Error while updating Train for a given route..............");
			e.printStackTrace();
		}
		log.info("updateGivenTrainforRoute............................."+res);
		return res;
	}

}

//{
//"source": "delhi",
//"destination": "jaipur",
//"trainList":[{
//    "id":"3",
//    "trainName":"A",
//    "arrivalTime":"8:00 AM",
//    "departureTime":"10:00 PM",
//    "fare":"2500.00"
//},{
//    "id":"4",
//    "trainName":"B",
//    "arrivalTime":"9:00 AM",
//    "departureTime":"11:00 PM",
//    "fare":"2500.00"
//}]
//}