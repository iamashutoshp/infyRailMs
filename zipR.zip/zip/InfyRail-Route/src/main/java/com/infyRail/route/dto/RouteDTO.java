package com.infyRail.route.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import com.infyRail.route.entity.RouteEntity;


public class RouteDTO {
	
	@Min(value = 100)
	@Max(value = 999)
	Integer routeId;
	@NotEmpty(message="{route.source.must}")
	@Pattern(regexp="^[A-Za-z]+$",message= "{route.source.invalid}")
	String source;
	@NotEmpty(message="{route.destination.must}")
	@Pattern(regexp="^[A-Za-z]+$",message= "{route.destination.invalid}")
	String destination;
//	@NotEmpty
	List<TrainDTO> trainList;

	
	public String getSource() {
		return source;
	}
	public Integer getRouteId() {
		return routeId;
	}
	public void setRouteId(Integer routeId) {
		this.routeId = routeId;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public List<TrainDTO> getTrainList() {
		return trainList;
	}
	public void setTrainList(List<TrainDTO> trainList) {
		this.trainList = trainList;
	}
	
	@Override
	public String toString() {
		return "routeDTO [routeId=" + routeId + ", source=" + source + ", destination=" + destination + ", trainList=" + trainList
				+ "]";
	}
	
	public static RouteEntity prepareRouteEntity(RouteDTO routeDTO) {
		RouteEntity routeEntity=new RouteEntity();
		
		routeEntity.setId(routeDTO.getRouteId());
		routeEntity.setDestination(routeDTO.getDestination());
		routeEntity.setSource(routeDTO.getSource());
		
		return routeEntity;
	}
	
	public static RouteDTO prepareRouteDTO(RouteEntity routeEntity) {
		RouteDTO routeDTO=new RouteDTO();
		
		routeDTO.setDestination(routeEntity.getDestination());
		routeDTO.setSource(routeEntity.getSource());
		routeDTO.setRouteId(routeEntity.getId());
		
		return routeDTO;
	}
}

