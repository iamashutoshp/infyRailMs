package com.infyRail.route.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infyRail.route.dto.RouteDTO;
import com.infyRail.route.dto.TrainDTO;
import com.infyRail.route.service.RouteService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("/routes")
@Validated
@CrossOrigin
public class RouteController {
	@Autowired
	private RouteService routeService;

	@Autowired
	private RestTemplate restTemplate;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	@PostMapping(consumes = "application/json")
	public ResponseEntity<String> createRoute(@Valid @RequestBody RouteDTO routeDTO) {
		return ResponseEntity.ok(routeService.createRoute(routeDTO));
	}

	@GetMapping(value = "/{routeId}")
	@HystrixCommand(fallbackMethod = "fetchRouteFallBack")
	public ResponseEntity<RouteDTO> fetchRoute(@PathVariable("routeId") String id) {
		int routeId = Integer.parseInt(id);
		log.info("fetching route for routeId : " + id);
		List<TrainDTO> trainDTOs = null;
		TrainDTO[] forNow = null;

//		fetching route from InfyRail-TrainMS
		log.info("making Get request to : " + "http://TRAINMS" + "/trainMS/trains?routeId=" + id);

//		load Balance
		forNow = restTemplate.getForObject("http://TRAINMS" + "/trainMS/trains?routeId=" + id, TrainDTO[].class);
		trainDTOs = Arrays.asList(forNow);
		log.info("Got response from : " + "http://TRAINMS" + "/trainMS/trains?routeId=" + id + " as : \n " + trainDTOs);

		return ResponseEntity.ok(routeService.fetchRoute(routeId, trainDTOs));
	}

	@GetMapping(value = "/trains")
	@HystrixCommand(fallbackMethod = "fetchTrainFallBack")
	public ResponseEntity<List<TrainDTO>> fetchTrain(@RequestParam("source") String source,
			@RequestParam("dest") String destination) {
		List<TrainDTO> trains = null;
		Integer routeId = null;
		routeId = routeService.getRouteForSourceAndDestination(source, destination);
		trains = Arrays.asList(
				restTemplate.getForObject("http://TRAINMS" + "/trainMS/trains?routeId=" + routeId, TrainDTO[].class));
		return ResponseEntity.ok(trains);
	}

	@PutMapping(value = "/{routeId}")
	public ResponseEntity<RouteDTO> updateRoute(@PathVariable("routeId") String id,
			@MatrixVariable Map<String, String> map) {
		log.info("updating Route for routeId : " + id + " with source & destination as : " + map);
		return ResponseEntity.ok(routeService.updateRoute(id, map.get("source"), map.get("destination")));
	}

	@PutMapping(value = "/{routeid}/json")
	@HystrixCommand(fallbackMethod = "updateTrainFallBack")
	public ResponseEntity<String> updateTrain(@PathVariable("routeid") String id,
			@RequestBody TrainDTO trainDTO) {
		log.info("inside updateTrain...");
		log.info("sending request for updating route : "+id+" foor trains : "+trainDTO);
		
		restTemplate.put("http://TRAINMS" + "/trainMS/trains/"+id+"/json", trainDTO);
		return ResponseEntity.ok("trains updated for routeId : " + id + "\n train: " + trainDTO);
	}

	@DeleteMapping(value = "/{routeId}/{trainId}")
	@HystrixCommand(fallbackMethod = "deleteTrainFallBack")
	public ResponseEntity<String> deleteTrain(@PathVariable("routeId") String route,
			@PathVariable("trainId") String train) {
		log.info("deleting train on routeId : " + route + " wiht trainNo : " + train);

		int routeId = Integer.parseInt(route);
		int trainId = Integer.parseInt(train);

		log.info(routeId + "---->" + trainId);
//		make request to TrainMS to delete the train if in this route
//		TrainDTO deleltedTrain = restTemplate.getForObject("http://TRAINMS" + "/trainMS/trains?routeId=" + id,
//				TrainDTO[].class);

		restTemplate.delete("http://TRAINMS" + "/trainMS/trains/" + route + "/" + train);

//		get deletion response

		return ResponseEntity.ok("Train no. :" + train + " deleted");
	}

//	fall back methods 

	public ResponseEntity<RouteDTO> fetchRouteFallBack(@PathVariable("routeId") String id) {

		List<TrainDTO> trainDTOs = null;
		int routeId = -1;
		log.info("fetchRouteFallBack for routeId=" + id);

		try {
			routeId = Integer.parseInt(id);
		} catch (NumberFormatException e) {
			log.error("Invalid routeId");
		}
		return ResponseEntity.ok(routeService.fetchRoute(routeId, trainDTOs));
	}

	public ResponseEntity<List<TrainDTO>> fetchTrainFallBack(@RequestParam("source") String source,
			@RequestParam("dest") String destination) {
		List<TrainDTO> trains = new ArrayList<>();
		log.info("in fetchTrainFallBack method..............");
		return ResponseEntity.ok(trains);
	}

	public ResponseEntity<String> deleteTrainFallBack(@PathVariable("routeId") String route,
			@PathVariable("trainId") String train) {
		log.info("in deleteTrainFallBack ................");
		return ResponseEntity.ok("Some error in deleting train");
	}

	public ResponseEntity<String> updateTrainFallBack(@PathVariable("routeid") String id,
			@RequestBody TrainDTO trainDTOs) {
		log.info("inside updateTrainFallback.....................................");
		return ResponseEntity
				.ok("update train for a given route falied :\n routeId : " + id + "\n trains : " + trainDTOs);
	}
}
