package com.infyRail.route.service;

import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infyRail.route.dto.RouteDTO;
import com.infyRail.route.dto.TrainDTO;
import com.infyRail.route.entity.RouteEntity;
import com.infyRail.route.repository.RouteRepo;

@Service
public class RouteService {

	@Autowired
	RouteRepo routeRepo;
	
	
	private Logger log = LoggerFactory.getLogger(this.getClass());
	
	
	public String createRoute(RouteDTO routeDTO) {
		RouteEntity routeEntity=RouteDTO.prepareRouteEntity(routeDTO);
//		routeRepo.saveAndFlush(routeEntity);
		log.info("adding new route for : "+routeDTO);
//		routeEntity.setId(routeDTO.getRouteId());
		System.out.println(routeEntity.getId());
		routeRepo.saveAndFlush(routeEntity);
		
		log.info("route added with routeId : "+routeEntity.getId());
		return String.valueOf(routeEntity.getId());
	}
	
	
	public RouteDTO fetchRoute(int id,List<TrainDTO> trainDTOs) {
		Optional<RouteEntity> en=routeRepo.findById(id);
		RouteDTO dto=null;
		if(en.isPresent()) {
			dto=RouteDTO.prepareRouteDTO(en.get());
			dto.setTrainList(trainDTOs);
		}
		
		log.info("returning "+dto+" from RouteService.fetchroute() for : "+id);
		return dto;
		
	}
	public List<TrainDTO> fetchTrain(String source,String destination) {
//		Optional<RouteEntity> ent=routeRepo.findBySourceAndDestination(source, destination);
//		if(ent.isPresent()) {
//			List<TrainDTO> trainDTO=TrainDTO.changeTo(ent.get().getTrainList());
//			return trainDTO;
//		}
		log.info("returning from RouteService.fetchTrain() for : source : "+source+"\n Destination : "+destination);
		return null;
	}
	
	public RouteDTO updateRoute(String id,String source,String destination) {
		Optional<RouteEntity> ent=routeRepo.findById(Integer.parseInt(id));
		RouteEntity entity=null;
		RouteDTO routeDTO=null;
		if(ent.isPresent()) {
			entity=ent.get();
			entity.setSource(source);
			entity.setDestination(destination);
			routeRepo.saveAndFlush(entity);
			routeDTO=RouteDTO.prepareRouteDTO(entity);
		}
		log.info("updating route for routeId : "+id+" to : source : "+source+"\n Destination : "+destination);
		return routeDTO;
	}
	
	public RouteDTO updateRoute1(String id,RouteDTO routeDTO) {
//		Optional<RouteEntity> ent=routeRepo.findById(Integer.parseInt(id));
//		if(ent.isPresent()) {
//			RouteEntity en=RouteDTO.change(routeDTO);
//			RouteEntity entity=ent.get();
//			if(en.getDestination()!=null) {
//				entity.setDestination(en.getDestination());
//			}
//			if(en.getId()!=null) {
//				entity.setId(en.getId());
//			}
//			if(en.getSource()!=null) {
//				entity.setSource(en.getSource());
//			}
//			if(en.getTrainList()!=null) {
//				List<TrainEntity> te=en.getTrainList();
//				 te.addAll(entity.getTrainList());
//				entity.setTrainList(te);
//			}
//			routeRepo.saveAndFlush(entity);
//			RouteDTO routeDTO1=RouteDTO.changeTo(entity);
//			return routeDTO1;
//		}
		log.info("returning from RouteService.updateRoute1() for : route : "+routeDTO);
		
		return null;
	}


	public Integer getRouteForSourceAndDestination(String source, String destination) {
		Integer routeId =  null;
		try {
			List<RouteEntity> routes=routeRepo.findBySourceAndDestination(source, destination);
			if(routes!=null)
				routeId=routes.get(0).getId();	
		} catch (Exception e) {
			log.error("can't get routeId....for  : "+source+" - "+destination);
			e.printStackTrace();
		}
		return routeId;
	}
}
