package com.infyRail.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfyRailEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
