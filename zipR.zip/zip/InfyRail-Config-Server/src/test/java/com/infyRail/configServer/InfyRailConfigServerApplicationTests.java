package com.infyRail.configServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfyRailConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
